// Dan Jansen | 26 Feb 2026 | Timeline
void setup() {
  size(950, 400);
}
void draw() {
  background(#416ACE);
  drawRef();
  histEvent(108, 200, "June 2009", true, "Detail text 1");
  histEvent(216, 300, "Apr. 2010", false, "Detail text 2");
  histEvent(324, 200, "June 2015", true, "Detail text 3");
  histEvent(432, 300, "May 2016", false, "Detail text 4");
  histEvent(540, 200, "2017-2018", true, "Detail text 5");
  histEvent(648, 300, "Dec. 2021", false, "Detail text 6");
  histEvent(756, 200, "May 2021", true, "Detail text 7");
  histEvent(864, 300, "June 2022", false, "Detail text 8");
}
void drawRef() {
  textAlign(CENTER);
  textSize(38);
  fill(255);
  text("Timeline", width/2, 65);
  textSize(20);
  text("By: Dan Jansen", width/2, 90);
  strokeWeight(3);
  line(50, 250, 900, 250);
  strokeWeight(2);
  line(50, 245, 50, 255);
  line(900, 245, 900, 255);
  line(475, 245, 475, 255);
  line(475,245,475,255);
  line(330,245,330,255);
  line(170,245,170,255);
  line(625,245,625,255);
  line(775,245,775,255);
  strokeWeight(1.5);
  textSize(15);
  text("2009", 50, 270);
  text("2022", 900, 270);
}
void histEvent(int x, int y, String title, boolean top, String detail) {
  if (top == true) {
    line(x, y, x-15, y+50);
  } else {
    line(x, y, x-15, y-50);
  }
  
    rectMode(CENTER);
    fill(170);
    rect(x, y, 120, 30, 8);
    fill(#222652);
    text(title, x, y+5);
    if (mouseX > x-60 && mouseX < x+60 && mouseY > y-15 && mouseY < y+15) {
      text(detail, width/2, 350);
    }
  }
