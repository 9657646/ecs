String password = "Password";
String userInput = "";
boolean checked = false;
boolean accessGranted = false;


void setup() {
  size(800, 600);
  textAlign(CENTER, CENTER);
  textSize(40);
}

void draw() {
  background(0);

  fill(255);
  text("Enter password to unlock safe.", width/2, 80);
  
  text("Password: " + userInput, width/2, 140);

  if (checked) {
    if (accessGranted) {
      background(0,255,0);
      text("Enter password to unlock safe.", width/2, 80);
  
      text("Password: " + userInput, width/2, 140);
      fill(255);
      text("ACCESS GRANTED", width/2, 300);
    } else {
      background(255, 0, 0);
       text("Enter password to unlock safe.", width/2, 80);
  
      text("Password: " + userInput, width/2, 140);
      fill(255);
      text("ACCESS DENIED", width/2, 300);
    }
  }
}

void keyPressed() {
  if (key == ENTER) {
    checked = true;

    if (userInput.equals(password)) {
      accessGranted = true;
    } else {
      accessGranted = false;
    }
  } 
  else if (key == BACKSPACE && userInput.length() > 0) {
    userInput = userInput.substring(0, userInput.length() - 1);
  } 

  else if (key != CODED) {
    userInput += key;
  }
}
